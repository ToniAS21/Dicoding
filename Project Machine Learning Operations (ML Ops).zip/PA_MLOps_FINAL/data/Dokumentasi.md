# Submission 1: Nama Proyek Anda
Nama: Toni Andreas Susanto

Username dicoding: toni_andreas_s

| | Deskripsi |
| ----------- | ----------- |
| Dataset | [Bank Marketing](https://www.kaggle.com/datasets/dhirajnirne/bank-marketing) |
| Masalah | Marketing merupakan salah satu kegiatan penting dalam bisnis. Penting sebab  |
| Solusi machine learning | Deskripsi solusi machine learning yang akan dibuat |
| Metode pengolahan | Deskripsi metode pengolahan data yang digunakan |
| Arsitektur model | Deskripsi arsitektur model yang diguanakan |
| Metrik evaluasi | Deksripsi metrik yang digunakan untuk mengevaluasi performa model |
| Performa model | Deksripsi performa model yang dibuat |
| Opsi deployment | Deksripsi tentang opsi deployment |
| Web app | Tautan web app yang digunakan untuk mengakses model serving. Contoh: [nama-model](https://model-resiko-kredit.herokuapp.com/v1/models/model-resiko-kredit/metadata)|
| Monitoring | Deksripsi terkait hasil monitoring dari model serving |